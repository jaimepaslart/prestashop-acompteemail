<?php
header('Location: ../');
exit;

